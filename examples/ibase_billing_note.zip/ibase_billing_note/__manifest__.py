{
    "name": "IBase - Billing Note",
    "version": "20.0.1.0.0",
    "category": "IBase/Accounting",
    "summary": "Group several invoices into one billing note, set the amount to pay per invoice, "
    "and register payments that reconcile each invoice by its own amount.",
    "author": "Imotif",
    "license": "LGPL-3",
    "contributors": [
        "Thewarat Kho.",
    ],
    "depends": [
        "account",
    ],
    "data": [
        "security/ir.access.csv",
        "data/ir_sequence_data.xml",
        "report/billing_note_report.xml",
        "report/billing_note_templates.xml",
        "data/mail_template_data.xml",
        "wizard/billing_note_register_payment_views.xml",
        "views/billing_note_views.xml",
        "views/account_move_views.xml",
        "views/account_payment_views.xml",
        "views/res_config_settings_views.xml",
        "views/menus.xml",
    ],
    "installable": True,
    "application": False,
}
