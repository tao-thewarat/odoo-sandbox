from odoo import Command
from odoo.exceptions import UserError, ValidationError
from odoo.tests import Form, tagged

from odoo.addons.account.tests.common import AccountTestInvoicingCommon
from odoo.addons.ibase_billing_note.models.bahttext import bahttext


@tagged('post_install', '-at_install')
class TestBillingNote(AccountTestInvoicingCommon):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.bank_journal = cls.company_data['default_journal_bank']
        cls.wht_account = cls.env['account.account'].create({
            'name': 'ภาษีถูกหัก ณ ที่จ่าย', 'code': '115100', 'account_type': 'asset_current',
        })
        cls.fee_account = cls.env['account.account'].create({
            'name': 'ค่าธรรมเนียมธนาคาร', 'code': '530500', 'account_type': 'expense',
        })
        cls.wht_vendor_account = cls.env['account.account'].create({
            'name': 'ภาษีหัก ณ ที่จ่ายค้างจ่าย', 'code': '215100', 'account_type': 'liability_current',
        })

    # -------------------------------------------------------------------------
    # HELPERS
    # -------------------------------------------------------------------------

    def _invoice(self, amount, move_type='out_invoice', partner=None):
        return self.init_invoice(move_type, partner=partner or self.partner_a, amounts=[amount], post=True)

    def _note(self, lines, bill_type='customer', partner=None, confirm=True):
        note = self.env['billing.note'].create({
            'bill_type': bill_type,
            'partner_id': (partner or self.partner_a).id,
            'line_ids': [Command.create({'move_id': move.id, 'amount_to_pay': amount}) for move, amount in lines],
        })
        if confirm:
            note.action_confirm()
        return note

    def _wizard(self, note, **vals):
        wizard = self.env['billing.note.register.payment'].with_context(
            default_billing_note_id=note.id).create({'journal_id': self.bank_journal.id, **vals})
        return wizard

    def _pay_on_invoice(self, invoice, amount):
        return self.env['account.payment.register'].with_context(
            active_model='account.move', active_ids=invoice.ids,
        ).create({
            'amount': amount,
            'payment_difference_handling': 'open',
            'journal_id': self.bank_journal.id,
        })._create_payments()

    # -------------------------------------------------------------------------
    # TESTS
    # -------------------------------------------------------------------------

    def test_full_partial_and_credit_note(self):
        """Example 1 of the design: INV1 in full, INV2 3,000 of 5,350, credit note 1,070 applied on INV2."""
        inv1 = self._invoice(10700)
        inv2 = self._invoice(5350)
        refund = self._invoice(1070, move_type='out_refund')
        # Credit notes are applied on the invoices in the order of the lines: INV2 first here.
        note = self._note([(inv2, 3000), (inv1, 10700), (refund, -1070)])

        self.assertEqual(note.state, 'confirmed')
        self.assertTrue(note.name.startswith('BN'))
        self.assertAlmostEqual(note.amount_to_pay, 12630)

        wizard = self._wizard(note)
        self.assertAlmostEqual(wizard.amount_cash_total, 12630)
        inv2_line = wizard.line_ids.filtered(lambda l: l.move_id == inv2)
        self.assertAlmostEqual(inv2_line.amount_credit, 1070)
        self.assertAlmostEqual(inv2_line.amount_cash, 1930)
        wizard.action_create_payments()

        self.assertRecordValues(inv1 + inv2 + refund, [
            {'amount_residual': 0.0},
            {'amount_residual': 2350.0},
            {'amount_residual': 0.0},
        ])
        self.assertEqual(sorted(note.payment_ids.mapped('amount')), [1930.0, 10700.0])
        self.assertEqual(note.state, 'paid')
        self.assertAlmostEqual(note.amount_residual, 0.0)
        self.assertAlmostEqual(note.amount_paid, 12630.0)

    def test_credit_note_without_origin_goes_to_first_invoice(self):
        inv1 = self._invoice(1000)
        inv2 = self._invoice(2000)
        refund = self._invoice(300, move_type='out_refund')
        note = self._note([(inv1, 1000), (inv2, 2000), (refund, -300)])
        wizard = self._wizard(note)
        line1 = wizard.line_ids.filtered(lambda l: l.move_id == inv1)
        self.assertAlmostEqual(line1.amount_credit, 300)
        self.assertAlmostEqual(line1.amount_cash, 700)
        wizard.action_create_payments()
        self.assertEqual((inv1 + inv2 + refund).mapped('amount_residual'), [0.0, 0.0, 0.0])
        self.assertEqual(sorted(note.payment_ids.mapped('amount')), [700.0, 2000.0])

    def test_credit_note_too_big_for_partial_invoice(self):
        """reconcile() cannot stop at the billed amount: a credit note larger than a partially billed invoice is refused."""
        inv = self._invoice(5000)
        refund = self._invoice(2000, move_type='out_refund')
        note = self._note([(inv, 3000), (refund, -1000)], confirm=False)
        with self.assertRaises(ValidationError):
            note.line_ids.filtered(lambda l: l.move_id == refund).amount_to_pay = 1000  # wrong sign
        note.action_confirm()
        wizard = self._wizard(note)
        with self.assertRaises(UserError):
            wizard.action_create_payments()

    def test_partial_payment_from_note(self):
        inv1 = self._invoice(1000)
        inv2 = self._invoice(2000)
        note = self._note([(inv1, 1000), (inv2, 2000)])
        wizard = self._wizard(note)
        wizard.line_ids.filtered(lambda l: l.move_id == inv2).amount_settle = 500
        wizard.action_create_payments()
        self.assertEqual(note.state, 'partial')
        self.assertAlmostEqual(note.amount_residual, 1500)
        self.assertAlmostEqual(inv2.amount_residual, 1500)

        # Second payment proposes only what is left.
        wizard = self._wizard(note)
        self.assertEqual(wizard.line_ids.move_id, inv2)
        self.assertAlmostEqual(wizard.line_ids.amount_settle, 1500)
        wizard.action_create_payments()
        self.assertEqual(note.state, 'paid')

    def test_over_billing_is_blocked(self):
        inv = self._invoice(5350)
        self._note([(inv, 3000)])
        # The default amount on a second note is what is still unbilled.
        note2 = self._note([], confirm=False)
        note2.line_ids = [Command.create({'move_id': inv.id})]
        self.assertAlmostEqual(note2.line_ids.amount_to_pay, 2350)
        note2.line_ids.amount_to_pay = 3000
        with self.assertRaises(UserError):
            note2.action_confirm()

    def test_amount_validation(self):
        inv = self._invoice(1000)
        with self.assertRaises(ValidationError):
            self._note([(inv, 1500)], confirm=False)
        refund = self._invoice(100, move_type='out_refund')
        with self.assertRaises(ValidationError):
            self._note([(refund, 100)], confirm=False)  # credit notes must be negative

    def test_withholding_tax_and_bank_fee(self):
        """Example 2: 10,700 invoice, 300 WHT, received 10,370 (30 bank fee)."""
        inv = self._invoice(10700)
        note = self._note([(inv, 10700)])
        wizard = self._wizard(note, wht_account_id=self.wht_account.id, writeoff_account_id=self.fee_account.id)
        wizard.line_ids.wht_amount = 300
        wizard.amount_received = 10370
        self.assertAlmostEqual(wizard.payment_difference, 30)
        wizard.action_create_payments()

        self.assertEqual(inv.amount_residual, 0.0)
        payment = note.payment_ids
        self.assertAlmostEqual(payment.amount, 10370)
        lines = payment.move_id.line_ids
        self.assertAlmostEqual(sum(lines.filtered(lambda l: l.account_id == self.wht_account).mapped('debit')), 300)
        self.assertAlmostEqual(sum(lines.filtered(lambda l: l.account_id == self.fee_account).mapped('debit')), 30)
        receivable = lines.filtered(lambda l: l.account_id.account_type == 'asset_receivable')
        self.assertAlmostEqual(receivable.credit, 10700)
        self.assertEqual(note.state, 'paid')

    def test_excess_received_is_kept_as_advance(self):
        inv = self._invoice(1000)
        note = self._note([(inv, 1000)])
        wizard = self._wizard(note)
        wizard.amount_received = 1200
        wizard.action_create_payments()
        self.assertEqual(inv.amount_residual, 0.0)
        self.assertEqual(len(note.payment_ids), 2)
        advance = note.payment_ids.filtered(lambda p: p.amount == 200)
        self.assertTrue(advance)
        self.assertFalse(advance.reconciled_invoice_ids)

    def test_payment_directly_on_invoice(self):
        """Design: billing note residual = min(still to collect, real invoice residual)."""
        inv = self._invoice(5350)
        note = self._note([(inv, 3000)])

        self._pay_on_invoice(inv, 1000)       # invoice still has 4,350 > 3,000 billed
        self.assertAlmostEqual(note.amount_residual, 3000)
        self.assertAlmostEqual(note.amount_paid_outside, 0)
        self.assertEqual(note.state, 'confirmed')

        self._pay_on_invoice(inv, 2000)       # invoice has 2,350 left
        self.assertAlmostEqual(note.amount_residual, 2350)
        self.assertAlmostEqual(note.amount_paid_outside, 650)
        self.assertEqual(note.state, 'partial')

        self._pay_on_invoice(inv, 2350)       # invoice fully paid
        self.assertAlmostEqual(note.amount_residual, 0)
        self.assertEqual(note.state, 'paid')

    def test_cancelled_payment_reopens_note(self):
        inv = self._invoice(1000)
        note = self._note([(inv, 1000)])
        self._wizard(note).action_create_payments()
        self.assertEqual(note.state, 'paid')
        with self.assertRaises(UserError):
            note.action_cancel()
        note.payment_ids.action_draft()
        note.payment_ids.action_cancel()
        self.assertEqual(note.state, 'confirmed')
        self.assertAlmostEqual(note.amount_residual, 1000)
        note.action_cancel()
        self.assertEqual(note.state, 'cancel')

    def test_invoice_reset_to_draft_blocked(self):
        inv = self._invoice(1000)
        self._note([(inv, 1000)])
        with self.assertRaises(UserError):
            inv.button_draft()

    def test_confirmed_note_is_locked(self):
        inv = self._invoice(1000)
        other = self._invoice(500)
        note = self._note([(inv, 1000)])
        with self.assertRaises(UserError):
            note.line_ids = [Command.create({'move_id': other.id})]

    def test_vendor_billing_note(self):
        bill1 = self._invoice(2000, move_type='in_invoice')
        bill2 = self._invoice(3000, move_type='in_invoice')
        note = self._note([(bill1, 2000), (bill2, 1000)], bill_type='vendor')
        self.assertTrue(note.name.startswith('RBN'))
        wizard = self._wizard(note, wht_account_id=self.wht_vendor_account.id)
        self.assertEqual(wizard.payment_type, 'outbound')
        wizard.line_ids.filtered(lambda l: l.move_id == bill1).wht_amount = 60
        wizard.action_create_payments()
        self.assertEqual(bill1.amount_residual, 0.0)
        self.assertEqual(bill2.amount_residual, 2000.0)
        self.assertEqual(note.state, 'paid')
        payment = note.payment_ids.filtered(lambda p: p.billing_note_line_id.move_id == bill1)
        self.assertAlmostEqual(payment.amount, 1940)
        wht_line = payment.move_id.line_ids.filtered(lambda l: l.account_id == self.wht_vendor_account)
        self.assertAlmostEqual(wht_line.credit, 60)

    def test_create_from_invoices(self):
        inv1 = self._invoice(1000)
        inv2 = self._invoice(2000)
        inv3 = self._invoice(500, partner=self.partner_b)
        action = (inv1 + inv2 + inv3).action_create_billing_note()
        notes = self.env['billing.note'].search([('line_ids.move_id', 'in', (inv1 + inv2 + inv3).ids)])
        self.assertEqual(len(notes), 2)
        self.assertEqual(notes.filtered(lambda n: n.partner_id == self.partner_a).line_ids.move_id, inv1 + inv2)
        self.assertTrue(action)

    def test_search_is_open_billing_note(self):
        billed = self._invoice(1000)
        unbilled = self._invoice(2000)
        self._note([(billed, 1000)])
        Move = self.env['account.move']
        both = [('id', 'in', (billed + unbilled).ids)]
        self.assertEqual(Move.search(both + [('is_open_billing_note', '=', True)]), billed)
        self.assertEqual(Move.search(both + [('is_open_billing_note', '=', False)]), unbilled)

    def test_fetch_open_invoices(self):
        inv1 = self._invoice(1000)
        inv2 = self._invoice(2000)
        paid = self._invoice(300)
        self._pay_on_invoice(paid, 300)
        note = self._note([], confirm=False)
        note.action_fetch_open_invoices()
        self.assertIn(inv1, note.line_ids.move_id)
        self.assertIn(inv2, note.line_ids.move_id)
        self.assertNotIn(paid, note.line_ids.move_id)

    def test_send_email_marks_as_sent(self):
        self.partner_a.email = 'customer@example.com'
        inv = self._invoice(1000)
        note = self._note([(inv, 1000)])
        action = note.action_send_email()
        composer = Form(self.env['mail.compose.message'].with_context(action['context']))
        composer.save().action_send_mail()
        self.assertTrue(note.is_sent)
        self.assertTrue(note.sent_date)

    def test_draft_note_cannot_be_sent_or_paid(self):
        inv = self._invoice(1000)
        note = self._note([(inv, 1000)], confirm=False)
        with self.assertRaises(UserError):
            note.action_send_email()
        with self.assertRaises(UserError):
            note.action_register_payment()

    def test_report_renders(self):
        inv = self._invoice(1000)
        note = self._note([(inv, 1000)])
        html = self.env['ir.actions.report']._render_qweb_html(
            'ibase_billing_note.action_report_billing_note', note.ids)[0]
        self.assertIn(note.name.encode(), html)

    def test_bahttext(self):
        self.assertEqual(bahttext(0), 'ศูนย์บาทถ้วน')
        self.assertEqual(bahttext(21), 'ยี่สิบเอ็ดบาทถ้วน')
        self.assertEqual(bahttext(101), 'หนึ่งร้อยเอ็ดบาทถ้วน')
        self.assertEqual(bahttext(12630), 'หนึ่งหมื่นสองพันหกร้อยสามสิบบาทถ้วน')
        self.assertEqual(bahttext(1250.50), 'หนึ่งพันสองร้อยห้าสิบบาทห้าสิบสตางค์')
        self.assertEqual(bahttext(11000000), 'สิบเอ็ดล้านบาทถ้วน')
        self.assertEqual(bahttext(0.25), 'ยี่สิบห้าสตางค์')

    def test_ui_flow_with_forms(self):
        """Create, confirm and pay a billing note through the form views (onchanges, domains, readonly)."""
        inv1 = self._invoice(1000)
        inv2 = self._invoice(2000)
        with Form(self.env['billing.note'].with_context(default_bill_type='customer')) as note_form:
            note_form.partner_id = self.partner_a
            with note_form.line_ids.new() as line:
                line.move_id = inv1
            with note_form.line_ids.new() as line:
                line.move_id = inv2
                self.assertAlmostEqual(line.amount_to_pay, 2000)
                line.amount_to_pay = 1500
        note = note_form.record
        self.assertAlmostEqual(note.amount_to_pay, 2500)
        note.action_confirm()

        action = note.action_register_payment()
        with Form(self.env[action['res_model']].with_context(action['context'])) as wizard_form:
            self.assertAlmostEqual(wizard_form.amount_cash_total, 2500)
            with wizard_form.line_ids.edit(1) as line:
                line.amount_settle = 1000
            self.assertAlmostEqual(wizard_form.amount_cash_total, 2000)
            self.assertAlmostEqual(wizard_form.amount_received, 2000)
        wizard_form.record.action_create_payments()
        self.assertEqual(note.state, 'partial')
        self.assertAlmostEqual(inv2.amount_residual, 1000)
        self.assertAlmostEqual(note.amount_residual, 500)
