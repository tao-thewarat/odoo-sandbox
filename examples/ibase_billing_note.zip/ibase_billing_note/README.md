# Billing Note (ใบวางบิล) — Odoo 20

Groups several invoices of one partner into a billing note, lets you set the amount to pay per
invoice, and registers payments that reconcile each invoice by exactly that amount.

## Features
- Customer billing notes (ใบวางบิล) and vendor billing notes (ใบรับวางบิล), numbered BN / RBN.
- Amount to pay per invoice (partial allowed), credit notes as negative lines.
- Confirm checks: same partner / company / currency, posted documents, no over-billing across open notes.
- **Pay** button: one payment per invoice (cash part), credit notes reconciled first,
  withholding tax and bank-fee difference as write-off lines, excess received kept as advance.
- Status computed from real reconciliations: Confirmed → Partially Paid → Paid. Payments made directly
  on an invoice are taken into account (amount due = min(still to collect, invoice amount due)).
- **Send** button (manual) with PDF attached; "Sent" flag kept separately from the status.
- PDF with amount in Thai words (บาทถ้วน), signature boxes.
- Invoice list action "Create Billing Note", filters "Not in a Billing Note", smart buttons.

## Setup
1. Accounting > Configuration > Settings > Billing Notes: set the WHT and difference accounts.
2. Bank journals: an Outstanding Receipts/Payments account on the payment methods is recommended.
   Without one, the module uses the company default outstanding account so payments always get a journal entry.
3. For Thai PDFs, install a Thai font on the server (e.g. `fonts-thai-tlwg`).

## Known limits (v1)
- A credit note is applied in full; it must fit in the amount billed of the invoice it is applied to
  (or that invoice must be paid in full), because Odoo's reconcile always settles the smaller residual.
- Credit notes created from an invoice with "Credit Note" are reconciled with it by Odoo at posting,
  so they no longer appear as open.

## Tests
`odoo-bin -d <db> -i ibase_billing_note --test-tags /ibase_billing_note --stop-after-init` (20 tests).
