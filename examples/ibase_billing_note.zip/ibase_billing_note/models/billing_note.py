from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError

from .bahttext import bahttext

MOVE_TYPES = {
    'customer': ('out_invoice', 'out_refund'),
    'vendor': ('in_invoice', 'in_refund'),
}
REFUND_TYPES = ('out_refund', 'in_refund')
POSTED_PAYMENT_STATES = ('paid', 'reconciled')


class BillingNote(models.Model):
    _name = 'billing.note'
    _description = "Billing Note"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'date desc, id desc'
    _check_company_auto = True

    name = fields.Char(string="Number", default='/', readonly=True, copy=False, tracking=True, index='trigram')
    bill_type = fields.Selection(
        selection=[('customer', "Customer Billing Note"), ('vendor', "Vendor Billing Note")],
        string="Type", required=True, default='customer',
    )
    partner_id = fields.Many2one(
        'res.partner', string="Partner", required=True, tracking=True, check_company=True,
        domain="[('parent_id', '=', False)]",
    )
    company_id = fields.Many2one('res.company', required=True, default=lambda self: self.env.company, index=True)
    currency_id = fields.Many2one(
        'res.currency', required=True, tracking=True,
        default=lambda self: self.env.company.currency_id,
    )
    date = fields.Date(string="Billing Date", required=True, default=fields.Date.context_today, tracking=True)
    payment_due_date = fields.Date(string="Payment Due Date", tracking=True,
                                   help="Date agreed with the partner to pay / collect the cheque.")
    user_id = fields.Many2one('res.users', string="Responsible", default=lambda self: self.env.user, tracking=True)
    note = fields.Text(string="Notes")
    line_ids = fields.One2many('billing.note.line', 'billing_note_id', string="Invoices", copy=True)

    stage = fields.Selection(
        selection=[('draft', "Draft"), ('open', "Open"), ('cancel', "Cancelled")],
        default='draft', required=True, copy=False, index=True,
    )
    state = fields.Selection(
        selection=[
            ('draft', "Draft"),
            ('confirmed', "Confirmed"),
            ('partial', "Partially Paid"),
            ('paid', "Paid"),
            ('cancel', "Cancelled"),
        ],
        compute='_compute_state', store=True, tracking=True, index=True,
    )

    amount_invoice_total = fields.Monetary(string="Invoices Total", compute='_compute_amounts', store=True)
    amount_to_pay = fields.Monetary(string="Amount Billed", compute='_compute_amounts', store=True)
    amount_paid = fields.Monetary(string="Paid via Billing Note", compute='_compute_amounts', store=True)
    amount_paid_outside = fields.Monetary(string="Paid Outside Billing Note", compute='_compute_amounts', store=True)
    amount_residual = fields.Monetary(string="Amount Due", compute='_compute_amounts', store=True)
    amount_text = fields.Char(string="Amount in Words", compute='_compute_amount_text')

    payment_ids = fields.One2many('account.payment', 'billing_note_id', string="Payments", readonly=True)
    payment_count = fields.Integer(compute='_compute_counts')
    invoice_count = fields.Integer(compute='_compute_counts')

    is_sent = fields.Boolean(string="Sent", copy=False, tracking=True)
    sent_date = fields.Datetime(string="Sent On", copy=False, readonly=True)

    # -------------------------------------------------------------------------
    # COMPUTE
    # -------------------------------------------------------------------------

    @api.depends('line_ids.amount_total', 'line_ids.amount_to_pay', 'line_ids.amount_paid',
                 'line_ids.amount_paid_outside', 'line_ids.amount_residual')
    def _compute_amounts(self):
        for note in self:
            lines = note.line_ids
            note.amount_invoice_total = sum(lines.mapped('amount_total'))
            note.amount_to_pay = sum(lines.mapped('amount_to_pay'))
            note.amount_paid = sum(lines.mapped('amount_paid'))
            note.amount_paid_outside = sum(lines.mapped('amount_paid_outside'))
            note.amount_residual = sum(lines.mapped('amount_residual'))

    @api.depends('stage', 'line_ids.amount_residual', 'line_ids.amount_paid', 'line_ids.amount_paid_outside')
    def _compute_state(self):
        for note in self:
            if note.stage != 'open':
                note.state = note.stage
                continue
            currency = note.currency_id
            lines = note.line_ids
            if lines and all(currency.is_zero(line.amount_residual) for line in lines):
                note.state = 'paid'
            elif any(not currency.is_zero(line.amount_paid) or not currency.is_zero(line.amount_paid_outside)
                     for line in lines):
                note.state = 'partial'
            else:
                note.state = 'confirmed'

    @api.depends('amount_to_pay', 'currency_id')
    def _compute_amount_text(self):
        for note in self:
            if note.currency_id.name == 'THB':
                note.amount_text = bahttext(note.amount_to_pay)
            else:
                note.amount_text = note.currency_id.amount_to_text(note.amount_to_pay)

    @api.depends('payment_ids', 'line_ids')
    def _compute_counts(self):
        for note in self:
            note.payment_count = len(note.payment_ids)
            note.invoice_count = len(note.line_ids)

    # -------------------------------------------------------------------------
    # CONSTRAINTS / ORM
    # -------------------------------------------------------------------------

    @api.constrains('partner_id', 'company_id', 'currency_id', 'bill_type', 'line_ids')
    def _check_lines_consistency(self):
        for note in self:
            for line in note.line_ids:
                move = line.move_id
                if move.commercial_partner_id != note.partner_id.commercial_partner_id:
                    raise ValidationError(_("%(move)s belongs to another partner than %(partner)s.",
                                            move=move.display_name, partner=note.partner_id.display_name))
                if move.company_id != note.company_id:
                    raise ValidationError(_("%(move)s belongs to another company.", move=move.display_name))
                if move.currency_id != note.currency_id:
                    raise ValidationError(_("%(move)s is in %(cur)s; the billing note is in %(note_cur)s.",
                                            move=move.display_name, cur=move.currency_id.name,
                                            note_cur=note.currency_id.name))
                if move.move_type not in MOVE_TYPES[note.bill_type]:
                    raise ValidationError(_("%(move)s cannot be added to this type of billing note.",
                                            move=move.display_name))

    def write(self, vals):
        locked_fields = {'partner_id', 'company_id', 'currency_id', 'bill_type', 'line_ids'}
        if locked_fields & vals.keys() and any(note.stage != 'draft' for note in self):
            raise UserError(_("Only draft billing notes can be modified. Cancel and reset it to draft first."))
        return super().write(vals)

    @api.ondelete(at_uninstall=False)
    def _unlink_except_numbered(self):
        for note in self:
            if note.stage == 'open':
                raise UserError(_("You cannot delete a confirmed billing note. Cancel it first."))
            if note.payment_ids:
                raise UserError(_("You cannot delete a billing note that has payments."))

    @api.depends('name', 'bill_type')
    def _compute_display_name(self):
        for note in self:
            note.display_name = note.name if note.name and note.name != '/' else _("Draft Billing Note")

    # -------------------------------------------------------------------------
    # HELPERS
    # -------------------------------------------------------------------------

    def _get_move_types(self):
        self.ensure_one()
        return MOVE_TYPES[self.bill_type]

    def _get_sequence_code(self):
        self.ensure_one()
        return 'billing.note.vendor' if self.bill_type == 'vendor' else 'billing.note'

    def _get_open_move_domain(self):
        self.ensure_one()
        domain = [
            ('state', '=', 'posted'),
            ('move_type', 'in', self._get_move_types()),
            ('commercial_partner_id', '=', self.partner_id.commercial_partner_id.id),
            ('company_id', '=', self.company_id.id),
            ('currency_id', '=', self.currency_id.id),
            ('amount_residual', '>', 0),
            ('id', 'not in', self.line_ids.move_id.ids),
        ]
        if self.payment_due_date:
            domain.append(('invoice_date_due', '<=', self.payment_due_date))
        return domain

    def _lock_moves(self, moves):
        if moves:
            self.env.cr.execute('SELECT id FROM account_move WHERE id IN %s FOR UPDATE', [tuple(moves.ids)])
            moves.invalidate_recordset(['amount_residual'])

    # -------------------------------------------------------------------------
    # ACTIONS
    # -------------------------------------------------------------------------

    def action_fetch_open_invoices(self):
        for note in self:
            if note.stage != 'draft':
                raise UserError(_("Invoices can only be added to a draft billing note."))
            moves = self.env['account.move'].search(note._get_open_move_domain(), order='invoice_date_due, id')
            line_model = self.env['billing.note.line']
            moves = moves.filtered(lambda move: not note.currency_id.is_zero(
                move.amount_residual - line_model._get_reserved_amount(move)))
            note.line_ids = [fields.Command.create({'move_id': move.id}) for move in moves]
        return True

    def action_confirm(self):
        for note in self:
            if note.stage != 'draft':
                raise UserError(_("Only draft billing notes can be confirmed."))
            if not note.line_ids:
                raise UserError(_("Add at least one invoice before confirming."))
            note._check_lines_consistency()
            moves = note.line_ids.move_id
            note._lock_moves(moves)
            currency = note.currency_id
            for line in note.line_ids:
                move = line.move_id
                if move.state != 'posted':
                    raise UserError(_("%s is not posted.", move.display_name))
                line._check_amount_to_pay_sign()
                reserved = line._get_reserved_elsewhere()
                available = move.amount_residual - reserved
                if currency.compare_amounts(abs(line.amount_to_pay), available) > 0:
                    raise UserError(_(
                        "%(move)s: the amount billed (%(billed)s) exceeds the amount still open "
                        "(%(open)s, after %(reserved)s already billed in other billing notes).",
                        move=move.display_name,
                        billed=currency.format(abs(line.amount_to_pay)),
                        open=currency.format(available),
                        reserved=currency.format(reserved),
                    ))
            if currency.compare_amounts(note.amount_to_pay, 0.0) <= 0:
                raise UserError(_("The total of a billing note must be positive: credit notes cannot exceed invoices."))
            if not note.name or note.name == '/':
                note.name = self.env['ir.sequence'].with_company(note.company_id).next_by_code(
                    note._get_sequence_code(), sequence_date=note.date) or '/'
            note.stage = 'open'
        return True

    def action_cancel(self):
        for note in self:
            if note.payment_ids.filtered(lambda p: p.state in POSTED_PAYMENT_STATES):
                raise UserError(_("Cancel the payments of %s before cancelling it.", note.display_name))
            if note.line_ids.billing_partial_ids.exists():
                raise UserError(_(
                    "Credit notes of %s are already reconciled with its invoices. "
                    "Unreconcile them before cancelling.", note.display_name))
            if note.is_sent:
                note.message_post(body=_("Billing note cancelled after it was sent to the partner."))
        self.stage = 'cancel'
        return True

    def action_draft(self):
        if any(note.stage != 'cancel' for note in self):
            raise UserError(_("Only cancelled billing notes can be reset to draft."))
        self.stage = 'draft'
        return True

    def action_register_payment(self):
        self.ensure_one()
        if self.state not in ('confirmed', 'partial'):
            raise UserError(_("Only confirmed or partially paid billing notes can be paid."))
        if self.currency_id.is_zero(self.amount_residual):
            raise UserError(_("Nothing left to pay on this billing note."))
        return {
            'name': _("Register Payment"),
            'type': 'ir.actions.act_window',
            'res_model': 'billing.note.register.payment',
            'view_mode': 'form',
            'target': 'new',
            'context': {'default_billing_note_id': self.id},
        }

    def action_view_payments(self):
        self.ensure_one()
        return self.payment_ids._get_records_action(name=_("Payments"), context={'create': False})

    def action_view_invoices(self):
        self.ensure_one()
        return self.line_ids.move_id._get_records_action(name=_("Invoices"), context={'create': False})

    def action_print(self):
        return self.env.ref('ibase_billing_note.action_report_billing_note').report_action(self)

    def action_send_email(self):
        if any(note.stage != 'open' for note in self):
            raise UserError(_("Only confirmed billing notes can be sent."))
        template = self.env.ref('ibase_billing_note.mail_template_billing_note', raise_if_not_found=False)
        ctx = {
            'default_model': 'billing.note',
            'default_res_ids': self.ids,
            'default_template_id': template.id if template else False,
            'default_composition_mode': 'comment' if len(self) == 1 else 'mass_mail',
            'default_email_layout_xmlid': 'mail.mail_notification_layout_with_responsible_signature',
            'email_notification_allow_footer': True,
            'force_email': True,
            'mark_billing_note_as_sent': True,
        }
        return {
            'name': _("Send Billing Note"),
            'type': 'ir.actions.act_window',
            'res_model': 'mail.compose.message',
            'view_mode': 'form',
            'views': [(False, 'form')],
            'target': 'new',
            'context': ctx,
        }

    def _mark_as_sent(self):
        self.filtered(lambda note: not note.is_sent).write({
            'is_sent': True,
            'sent_date': fields.Datetime.now(),
        })

    def message_post(self, **kwargs):
        if self.env.context.get('mark_billing_note_as_sent'):
            self._mark_as_sent()
        return super().message_post(**kwargs)

    def _message_mail_after_hook(self, mails):
        if self.env.context.get('mark_billing_note_as_sent'):
            self._mark_as_sent()
        return super()._message_mail_after_hook(mails)

    def _get_report_base_filename(self):
        self.ensure_one()
        return _("Billing Note - %s", self.name)
