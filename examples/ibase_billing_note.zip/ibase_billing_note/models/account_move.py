from collections import defaultdict

from odoo import api, fields, models, Command
from odoo.exceptions import UserError

from .billing_note import MOVE_TYPES


class AccountMove(models.Model):
    _inherit = "account.move"

    billing_note_line_ids = fields.One2many(
        comodel_name="billing.note.line",
        inverse_name="move_id",
        string="Billing Note Lines",
        readonly=True,
    )
    billing_note_count = fields.Integer(
        compute="_compute_billing_note_count",
    )
    is_open_billing_note = fields.Boolean(
        string="In Open Billing Note",
        compute="_compute_is_open_billing_note",
        search="_search_is_open_billing_note",
    )

    @api.depends("billing_note_line_ids.stage")
    def _compute_billing_note_count(self):
        for rec in self:
            rec.billing_note_count = len(rec._get_active_billing_notes())

    @api.depends("billing_note_line_ids.stage")
    def _compute_is_open_billing_note(self):
        for rec in self:
            rec.is_open_billing_note = bool(rec._get_open_billing_notes())

    def _search_is_open_billing_note(self, operator, value):
        if operator != "in":
            return NotImplemented
        domain = [("billing_note_line_ids", "any", [("stage", "=", "open")])]
        if True in value and False in value:
            return []
        return domain if True in value else ["!", *domain]

    def _get_active_billing_notes(self):
        return self.billing_note_line_ids.filtered(
            lambda x: x.stage != "cancel"
        ).billing_note_id

    def _get_open_billing_notes(self):
        return self.billing_note_line_ids.filtered(
            lambda x: x.stage == "open"
        ).billing_note_id

    def button_draft(self):
        for rec in self:
            if notes := rec._get_active_billing_notes():
                raise UserError(
                    self.env._(
                        "%(move)s is part of billing note(s) %(notes)s. Remove "
                        "it from them (or cancel them) "
                        "before resetting it to draft.",
                        move=rec.display_name,
                        notes=", ".join(notes.mapped("display_name")),
                    )
                )
        return super().button_draft()

    def action_view_billing_notes(self):
        self.ensure_one()
        return self._get_active_billing_notes()._get_records_action(
            name=self.env._("Billing Notes")
        )

    def action_create_billing_note(self):
        """
        Create one draft billing note
        per partner / currency / company / type from the selected invoices.
        """
        bill_type_by_move_type = {
            move_type: bill_type
            for bill_type, move_types in MOVE_TYPES.items()
            for move_type in move_types
        }
        line_model = self.env["billing.note.line"]
        moves = self.filtered(
            lambda x: x.state == "posted"
            and x.move_type in bill_type_by_move_type
            and not x.currency_id.is_zero(
                x.amount_residual - line_model._get_reserved_amount(x)
            )
        )
        groups = defaultdict(lambda: self.env["account.move"])
        for move in moves:
            key = (
                move.commercial_partner_id,
                move.currency_id,
                move.company_id,
                bill_type_by_move_type[move.move_type],
            )
            groups[key] |= move
        notes = self.env["billing.note"]
        for (partner, currency, company, bill_type), group_moves in groups.items():
            notes |= notes.with_company(company).create(
                {
                    "bill_type": bill_type,
                    "partner_id": partner.id,
                    "currency_id": currency.id,
                    "company_id": company.id,
                    "line_ids": [
                        Command.create({"move_id": move.id})
                        for move in group_moves.sorted(
                            lambda x: (x.invoice_date_due or x.date, x.id)
                        )
                    ],
                }
            )
        if not notes:
            raise UserError(
                self.env._(
                    "Select posted invoices that still have an amount due "
                    "and are not fully billed in open billing notes."
                )
            )
        return notes._get_records_action(name=self.env._("Billing Notes"))
