from odoo import fields, models


class ResCompany(models.Model):
    _inherit = 'res.company'

    billing_note_wht_account_id = fields.Many2one(
        'account.account', string="Withholding Tax Account (Customers)",
        help="Default account for withholding tax deducted by customers when paying a billing note.")
    billing_note_wht_vendor_account_id = fields.Many2one(
        'account.account', string="Withholding Tax Account (Vendors)",
        help="Default account for withholding tax you deduct when paying a vendor billing note.")
    billing_note_writeoff_account_id = fields.Many2one(
        'account.account', string="Payment Difference Account",
        help="Default account for bank fees / rounding differences when paying a billing note.")
