from odoo import _, api, fields, models
from odoo.exceptions import ValidationError

from .billing_note import REFUND_TYPES


class BillingNoteLine(models.Model):
    _name = 'billing.note.line'
    _description = "Billing Note Line"
    _order = 'sequence, id'
    _check_company_auto = True

    billing_note_id = fields.Many2one('billing.note', required=True, ondelete='cascade', index=True)
    sequence = fields.Integer(default=10)
    company_id = fields.Many2one(related='billing_note_id.company_id', store=True, index=True)
    currency_id = fields.Many2one(related='billing_note_id.currency_id', store=True)
    stage = fields.Selection(related='billing_note_id.stage', store=True)
    state = fields.Selection(related='billing_note_id.state')

    move_id = fields.Many2one(
        'account.move', string="Invoice", required=True, ondelete='restrict', index=True, check_company=True,
    )
    move_type = fields.Selection(related='move_id.move_type')
    invoice_date = fields.Date(related='move_id.invoice_date')
    invoice_date_due = fields.Date(related='move_id.invoice_date_due')
    ref = fields.Char(related='move_id.ref', string="Reference")

    amount_total = fields.Monetary(string="Invoice Total", compute='_compute_move_amounts', store=True)
    move_residual = fields.Monetary(string="Invoice Amount Due", compute='_compute_move_amounts', store=True)
    amount_to_pay = fields.Monetary(
        string="Amount to Pay", compute='_compute_amount_to_pay', store=True, readonly=False, precompute=True,
        help="Amount of this invoice settled by the billing note (cash + credit notes + withholding tax). "
             "Credit notes are negative.",
    )
    amount_paid = fields.Monetary(string="Paid via Billing Note", compute='_compute_amounts', store=True)
    amount_paid_outside = fields.Monetary(string="Paid Outside", compute='_compute_amounts', store=True)
    amount_residual = fields.Monetary(string="Amount Due", compute='_compute_amounts', store=True)

    billing_partial_ids = fields.Many2many(
        'account.partial.reconcile', 'billing_note_line_partial_rel', 'line_id', 'partial_id',
        string="Reconciliations", copy=False, readonly=True,
        help="Reconciliations created by this billing note (payments and credit notes).",
    )

    _move_uniq = models.Constraint(
        'UNIQUE(billing_note_id, move_id)',
        "An invoice can only appear once in a billing note.",
    )

    # -------------------------------------------------------------------------
    # HELPERS
    # -------------------------------------------------------------------------

    def _get_sign(self):
        self.ensure_one()
        return -1 if self.move_id.move_type in REFUND_TYPES else 1

    def _get_reserved_elsewhere(self):
        """Open amount of this invoice already billed in other open billing notes (unsigned)."""
        self.ensure_one()
        exclude = self.ids if isinstance(self.id, int) else []
        return self._get_reserved_amount(self.move_id, exclude)

    @api.model
    def _get_reserved_amount(self, move, exclude_line_ids=()):
        if not move:
            return 0.0
        others = self.search([
            ('move_id', '=', move.id),
            ('stage', '=', 'open'),
            ('id', 'not in', list(exclude_line_ids)),
        ])
        return sum(abs(amount) for amount in others.mapped('amount_residual'))

    def _get_amount_via_note(self):
        """Amount settled through the reconciliations made by this billing note, in the invoice currency."""
        self.ensure_one()
        amount = 0.0
        for partial in self.billing_partial_ids.exists():
            if partial.debit_move_id.move_id == self.move_id:
                amount += partial.debit_amount_currency
            elif partial.credit_move_id.move_id == self.move_id:
                amount += partial.credit_amount_currency
        return amount

    def _check_amount_to_pay_sign(self):
        for line in self:
            currency = line.currency_id
            if currency.is_zero(line.amount_to_pay):
                raise ValidationError(_("%s: the amount to pay cannot be zero.", line.move_id.display_name))
            if (line.amount_to_pay > 0) != (line._get_sign() > 0):
                raise ValidationError(_(
                    "%s: use a positive amount for invoices and a negative amount for credit notes.",
                    line.move_id.display_name))

    # -------------------------------------------------------------------------
    # COMPUTE
    # -------------------------------------------------------------------------

    @api.depends('move_id.amount_total', 'move_id.amount_residual', 'move_id.move_type')
    def _compute_move_amounts(self):
        for line in self:
            sign = line._get_sign() if line.move_id else 1
            line.amount_total = sign * line.move_id.amount_total
            line.move_residual = sign * line.move_id.amount_residual

    @api.depends('move_id')
    def _compute_amount_to_pay(self):
        for line in self:
            if not line.move_id:
                line.amount_to_pay = 0.0
                continue
            available = max(0.0, line.move_id.amount_residual - line._get_reserved_elsewhere())
            line.amount_to_pay = line._get_sign() * line.move_id.currency_id.round(available)

    @api.depends('stage', 'amount_to_pay', 'move_id.amount_residual',
                 'billing_partial_ids', 'billing_partial_ids.debit_amount_currency',
                 'billing_partial_ids.credit_amount_currency')
    def _compute_amounts(self):
        for line in self:
            sign = line._get_sign() if line.move_id else 1
            to_pay = abs(line.amount_to_pay)
            currency = line.currency_id or line.move_id.currency_id
            if line.stage != 'open' or not line.move_id:
                via_note = line._get_amount_via_note() if line.move_id else 0.0
                residual = max(0.0, to_pay - via_note)
            else:
                via_note = line._get_amount_via_note()
                # Never more than what is really still open on the invoice: payments registered
                # directly on the invoice reduce what the billing note still has to collect.
                residual = max(0.0, min(to_pay - via_note, line.move_id.amount_residual))
            outside = max(0.0, to_pay - via_note - residual)
            line.amount_paid = sign * currency.round(via_note)
            line.amount_residual = sign * currency.round(residual)
            line.amount_paid_outside = sign * currency.round(outside)

    @api.constrains('amount_to_pay', 'move_id')
    def _check_amount_to_pay(self):
        for line in self.filtered(lambda line: line.stage == 'draft' and line.move_id):
            line._check_amount_to_pay_sign()
            if line.currency_id.compare_amounts(abs(line.amount_to_pay), line.move_id.amount_residual) > 0:
                raise ValidationError(_(
                    "%(move)s: the amount to pay cannot exceed the invoice amount due (%(due)s).",
                    move=line.move_id.display_name,
                    due=line.currency_id.format(line.move_id.amount_residual)))
