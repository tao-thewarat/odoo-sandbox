from odoo import fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    billing_note_wht_account_id = fields.Many2one(
        related='company_id.billing_note_wht_account_id', readonly=False)
    billing_note_wht_vendor_account_id = fields.Many2one(
        related='company_id.billing_note_wht_vendor_account_id', readonly=False)
    billing_note_writeoff_account_id = fields.Many2one(
        related='company_id.billing_note_writeoff_account_id', readonly=False)
