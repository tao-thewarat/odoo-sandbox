from odoo import fields, models


class AccountPayment(models.Model):
    _inherit = 'account.payment'

    billing_note_id = fields.Many2one('billing.note', string="Billing Note", readonly=True, copy=False,
                                      index='btree_not_null', check_company=True)
    billing_note_line_id = fields.Many2one('billing.note.line', string="Billing Note Line", readonly=True,
                                           copy=False, ondelete='set null')
