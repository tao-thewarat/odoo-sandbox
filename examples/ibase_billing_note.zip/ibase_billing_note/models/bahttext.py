"""Convert an amount to Thai words (บาทถ้วน), as printed on Thai billing documents."""

_DIGITS = ['', 'หนึ่ง', 'สอง', 'สาม', 'สี่', 'ห้า', 'หก', 'เจ็ด', 'แปด', 'เก้า']
_POSITIONS = ['', 'สิบ', 'ร้อย', 'พัน', 'หมื่น', 'แสน']


def _read_under_million(number):
    """Read 0 < number < 1,000,000 in Thai."""
    text = ''
    digits = str(number)
    length = len(digits)
    for index, char in enumerate(digits):
        digit = int(char)
        position = length - index - 1
        if digit == 0:
            continue
        if position == 0 and digit == 1 and length > 1:
            text += 'เอ็ด'
        elif position == 1 and digit == 2:
            text += 'ยี่' + _POSITIONS[position]
        elif position == 1 and digit == 1:
            text += _POSITIONS[position]
        else:
            text += _DIGITS[digit] + _POSITIONS[position]
    return text


def _read_integer(number):
    if number == 0:
        return 'ศูนย์'
    parts = []
    while number > 0:
        parts.append(number % 1_000_000)
        number //= 1_000_000
    text = ''
    for index in range(len(parts) - 1, -1, -1):
        chunk = parts[index]
        if chunk:
            text += _read_under_million(chunk)
        if index > 0:
            text += 'ล้าน'
    return text


def bahttext(amount):
    """Return the Thai reading of an amount in baht, e.g. 1,250.50 -> หนึ่งพันสองร้อยห้าสิบบาทห้าสิบสตางค์."""
    amount = round(float(amount or 0.0), 2)
    prefix = ''
    if amount < 0:
        prefix = 'ลบ'
        amount = -amount
    satang_total = int(round(amount * 100))
    baht, satang = divmod(satang_total, 100)
    if baht == 0 and satang == 0:
        return 'ศูนย์บาทถ้วน'
    text = prefix
    if baht:
        text += _read_integer(baht) + 'บาท'
    if satang:
        text += _read_integer(satang) + 'สตางค์'
    else:
        text += 'ถ้วน'
    return text
