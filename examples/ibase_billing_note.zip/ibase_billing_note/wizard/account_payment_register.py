from odoo import _, api, fields, models


class AccountPaymentRegister(models.TransientModel):
    _inherit = 'account.payment.register'

    billing_note_warning = fields.Char(compute='_compute_billing_note_warning')

    @api.depends('line_ids')
    def _compute_billing_note_warning(self):
        for wizard in self:
            notes = wizard.line_ids.move_id._get_open_billing_notes()
            if notes:
                wizard.billing_note_warning = _(
                    "These invoices are part of open billing note(s) %s. Registering the payment from the "
                    "billing note keeps it up to date; paying here is still taken into account.",
                    ", ".join(notes.mapped('display_name')))
            else:
                wizard.billing_note_warning = False
