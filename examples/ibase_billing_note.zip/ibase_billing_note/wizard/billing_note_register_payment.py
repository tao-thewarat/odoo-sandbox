from odoo import Command, _, api, fields, models
from odoo.exceptions import UserError


class BillingNoteRegisterPayment(models.TransientModel):
    _name = 'billing.note.register.payment'
    _description = "Register Payment from Billing Note"
    _check_company_auto = True

    billing_note_id = fields.Many2one('billing.note', required=True, readonly=True)
    company_id = fields.Many2one(related='billing_note_id.company_id')
    currency_id = fields.Many2one(related='billing_note_id.currency_id')
    partner_id = fields.Many2one(related='billing_note_id.partner_id')
    bill_type = fields.Selection(related='billing_note_id.bill_type')
    payment_type = fields.Selection(
        [('inbound', "Receive"), ('outbound', "Send")], compute='_compute_payment_type')

    journal_id = fields.Many2one(
        'account.journal', string="Journal", required=True, check_company=True,
        compute='_compute_journal_id', store=True, readonly=False, precompute=True,
        domain="[('type', 'in', ('bank', 'cash')), ('company_id', '=', company_id)]",
    )
    available_payment_method_line_ids = fields.Many2many(
        'account.payment.method.line', compute='_compute_available_payment_method_line_ids')
    payment_method_line_id = fields.Many2one(
        'account.payment.method.line', string="Payment Method", required=True,
        compute='_compute_payment_method_line_id', store=True, readonly=False, precompute=True,
        domain="[('id', 'in', available_payment_method_line_ids)]",
    )
    payment_date = fields.Date(string="Payment Date", required=True, default=fields.Date.context_today)
    communication = fields.Char(string="Memo", compute='_compute_communication', store=True, readonly=False)

    line_ids = fields.One2many('billing.note.register.payment.line', 'wizard_id', string="Lines",
                               compute='_compute_line_ids', store=True, readonly=False, precompute=True)

    amount_settle_total = fields.Monetary(string="Amount Settled", compute='_compute_totals')
    amount_credit_total = fields.Monetary(string="Credit Notes", compute='_compute_totals')
    amount_wht_total = fields.Monetary(string="Withholding Tax", compute='_compute_totals')
    amount_cash_total = fields.Monetary(string="Cash Expected", compute='_compute_totals')
    amount_received = fields.Monetary(
        string="Amount Received / Paid", compute='_compute_amount_received', store=True, readonly=False,
        help="Amount that really reaches (or leaves) the bank. A difference with the expected cash is booked "
             "on the difference account (bank fees, rounding). An excess is kept as an advance payment.")
    payment_difference = fields.Monetary(compute='_compute_payment_difference')
    writeoff_account_id = fields.Many2one(
        'account.account', string="Difference Account", check_company=True,
        compute='_compute_default_accounts', store=True, readonly=False)
    writeoff_label = fields.Char(string="Difference Label", default=lambda self: _("Bank fee / difference"))
    wht_account_id = fields.Many2one(
        'account.account', string="Withholding Tax Account", check_company=True,
        compute='_compute_default_accounts', store=True, readonly=False)

    # -------------------------------------------------------------------------
    # COMPUTE
    # -------------------------------------------------------------------------

    @api.depends('billing_note_id.bill_type')
    def _compute_payment_type(self):
        for wizard in self:
            wizard.payment_type = 'outbound' if wizard.billing_note_id.bill_type == 'vendor' else 'inbound'

    @api.depends('billing_note_id.company_id')
    def _compute_journal_id(self):
        for wizard in self:
            if not wizard.journal_id:
                wizard.journal_id = self.env['account.journal'].search([
                    *self.env['account.journal']._check_company_domain(wizard.billing_note_id.company_id),
                    ('type', '=', 'bank'),
                ], limit=1)

    def _get_available_payment_method_lines(self):
        self.ensure_one()
        if not self.journal_id:
            return self.env['account.payment.method.line']
        payment_type = 'outbound' if self.billing_note_id.bill_type == 'vendor' else 'inbound'
        return self.journal_id._get_available_payment_method_lines(payment_type)

    @api.depends('journal_id', 'billing_note_id.bill_type')
    def _compute_available_payment_method_line_ids(self):
        for wizard in self:
            wizard.available_payment_method_line_ids = wizard._get_available_payment_method_lines()

    @api.depends('journal_id', 'billing_note_id.bill_type')
    def _compute_payment_method_line_id(self):
        for wizard in self:
            available = wizard._get_available_payment_method_lines()
            if wizard.payment_method_line_id not in available:
                wizard.payment_method_line_id = available[:1]

    @api.depends('billing_note_id')
    def _compute_communication(self):
        for wizard in self:
            wizard.communication = wizard.billing_note_id.name

    @api.depends('billing_note_id')
    def _compute_line_ids(self):
        for wizard in self:
            commands = [Command.clear()]
            for note_line in wizard.billing_note_id.line_ids:
                open_amount = abs(note_line.amount_residual)
                if wizard.currency_id.is_zero(open_amount):
                    continue
                commands.append(Command.create({
                    'note_line_id': note_line.id,
                    'amount_open': open_amount,
                    'amount_settle': open_amount,
                }))
            wizard.line_ids = commands

    @api.depends('company_id', 'bill_type')
    def _compute_default_accounts(self):
        for wizard in self:
            company = wizard.company_id
            if not wizard.writeoff_account_id:
                wizard.writeoff_account_id = company.billing_note_writeoff_account_id
            if not wizard.wht_account_id:
                wizard.wht_account_id = (company.billing_note_wht_vendor_account_id if wizard.bill_type == 'vendor'
                                         else company.billing_note_wht_account_id)

    @api.depends('line_ids.amount_settle', 'line_ids.wht_amount', 'line_ids.is_refund')
    def _compute_totals(self):
        for wizard in self:
            invoices = wizard.line_ids.filtered(lambda line: not line.is_refund)
            refunds = wizard.line_ids.filtered('is_refund')
            wizard.amount_settle_total = sum(invoices.mapped('amount_settle'))
            wizard.amount_credit_total = sum(refunds.mapped('amount_settle'))
            wizard.amount_wht_total = sum(invoices.mapped('wht_amount'))
            wizard.amount_cash_total = (wizard.amount_settle_total - wizard.amount_credit_total
                                        - wizard.amount_wht_total)

    @api.depends('amount_cash_total')
    def _compute_amount_received(self):
        for wizard in self:
            wizard.amount_received = wizard.amount_cash_total

    @api.depends('amount_cash_total', 'amount_received')
    def _compute_payment_difference(self):
        for wizard in self:
            wizard.payment_difference = wizard.amount_cash_total - wizard.amount_received

    # -------------------------------------------------------------------------
    # CREDIT NOTE ALLOCATION
    # -------------------------------------------------------------------------

    def _allocate_credit_notes(self):
        """Spread the credit notes over the invoices of the wizard.

        :return: (list of (refund_line, invoice_line, amount), unallocated amount)
        """
        self.ensure_one()
        currency = self.currency_id
        invoices = self.line_ids.filtered(lambda line: not line.is_refund)
        refunds = self.line_ids.filtered(lambda line: line.is_refund and not currency.is_zero(line.amount_settle))
        capacity = {line: line.amount_settle - line.wht_amount for line in invoices}
        allocations = []
        unallocated = 0.0
        for refund in refunds:
            remaining = refund.amount_settle
            reversed_move = refund.move_id.reversed_entry_id
            ordered = invoices.filtered(lambda line: line.move_id == reversed_move) \
                + invoices.filtered(lambda line: line.move_id != reversed_move)
            for invoice in ordered:
                if currency.compare_amounts(remaining, 0.0) <= 0:
                    break
                amount = min(remaining, capacity[invoice])
                if currency.compare_amounts(amount, 0.0) <= 0:
                    continue
                allocations.append((refund, invoice, currency.round(amount)))
                capacity[invoice] -= amount
                remaining -= amount
            unallocated += max(0.0, remaining)
        return allocations, currency.round(unallocated)

    # -------------------------------------------------------------------------
    # PAYMENT CREATION
    # -------------------------------------------------------------------------

    def _get_term_lines(self, move):
        domain = [
            ('parent_state', '=', 'posted'),
            ('account_type', 'in', self.env['account.payment']._get_valid_payment_account_types()),
            ('reconciled', '=', False),
        ]
        return move.line_ids.filtered_domain(domain)

    def _reconcile_and_track(self, lines, note_lines):
        """Reconcile journal items and remember the partials created on the billing note lines."""
        before = lines.matched_debit_ids | lines.matched_credit_ids
        for account in lines.account_id:
            lines.filtered(lambda line: line.account_id == account and not line.reconciled).reconcile()
        partials = (lines.matched_debit_ids | lines.matched_credit_ids) - before
        for note_line in note_lines:
            note_line.billing_partial_ids = [Command.link(partial.id) for partial in partials]
        return partials

    def _writeoff_vals(self, account, label, amount):
        sign = 1 if self.payment_type == 'inbound' else -1
        amount_currency = sign * amount
        return {
            'name': label,
            'account_id': account.id,
            'partner_id': self.partner_id.commercial_partner_id.id,
            'currency_id': self.currency_id.id,
            'amount_currency': amount_currency,
            'balance': self.currency_id._convert(amount_currency, self.company_id.currency_id,
                                                 self.company_id, self.payment_date),
        }

    def _prepare_payment_vals(self, amount, memo, destination_account=None, note_line=None, writeoffs=None):
        vals = {
            'date': self.payment_date,
            'amount': amount,
            'payment_type': self.payment_type,
            'partner_type': 'supplier' if self.bill_type == 'vendor' else 'customer',
            'memo': memo,
            'journal_id': self.journal_id.id,
            'company_id': self.company_id.id,
            'currency_id': self.currency_id.id,
            'partner_id': self.partner_id.commercial_partner_id.id,
            'payment_method_line_id': self.payment_method_line_id.id,
            'billing_note_id': self.billing_note_id.id,
            'billing_note_line_id': note_line.id if note_line else False,
            'write_off_line_vals': writeoffs or [],
        }
        if destination_account:
            vals['destination_account_id'] = destination_account.id
        return vals

    def _check_lines(self):
        self.ensure_one()
        currency = self.currency_id
        if not self.line_ids:
            raise UserError(_("Nothing to pay."))
        for line in self.line_ids:
            move = line.move_id
            if currency.compare_amounts(line.amount_settle, 0.0) < 0:
                raise UserError(_("%s: the amount cannot be negative.", move.display_name))
            limit = min(line.amount_open, move.amount_residual)
            if currency.compare_amounts(line.amount_settle, limit) > 0:
                raise UserError(_("%(move)s: you can settle at most %(limit)s.",
                                  move=move.display_name, limit=currency.format(limit)))
            if line.is_refund and not currency.is_zero(line.wht_amount):
                raise UserError(_("%s: no withholding tax on a credit note.", move.display_name))
            if currency.compare_amounts(line.wht_amount, 0.0) < 0 \
                    or currency.compare_amounts(line.wht_amount, line.amount_settle) > 0:
                raise UserError(_("%s: the withholding tax must be between zero and the settled amount.",
                                  move.display_name))
        if not currency.is_zero(self.amount_wht_total) and not self.wht_account_id:
            raise UserError(_("Set a withholding tax account."))
        if currency.compare_amounts(self.payment_difference, 0.0) > 0 and not self.writeoff_account_id:
            raise UserError(_("Set a difference account to book the %s difference.",
                              currency.format(self.payment_difference)))
        if currency.compare_amounts(self.amount_settle_total + self.amount_credit_total, 0.0) <= 0:
            raise UserError(_("Nothing to pay."))

    def action_create_payments(self):
        self.ensure_one()
        note = self.billing_note_id
        currency = self.currency_id
        if note.state not in ('confirmed', 'partial'):
            raise UserError(_("This billing note cannot be paid in its current state."))
        note._lock_moves(self.line_ids.move_id)
        self._check_lines()

        # 1. Credit notes against invoices of the same billing note.
        allocations, unallocated = self._allocate_credit_notes()
        if not currency.is_zero(unallocated):
            raise UserError(_("The credit notes exceed the invoices being paid by %s.", currency.format(unallocated)))
        credit_by_invoice = {}
        for refund, invoice, amount in allocations:
            refund_lines = self._get_term_lines(refund.move_id)
            invoice_lines = self._get_term_lines(invoice.move_id)
            # reconcile() always settles min(residuals): make sure this matches the amount we want.
            expected = min(refund.move_id.amount_residual, invoice.move_id.amount_residual)
            if currency.compare_amounts(expected, amount) != 0:
                raise UserError(_(
                    "Credit note %(refund)s (%(refund_amount)s) can only be applied in full on %(invoice)s, "
                    "or on an invoice paid in full by this billing note. Adjust the amounts to pay.",
                    refund=refund.move_id.display_name, refund_amount=currency.format(refund.amount_settle),
                    invoice=invoice.move_id.display_name))
            self._reconcile_and_track(refund_lines + invoice_lines, refund.note_line_id + invoice.note_line_id)
            credit_by_invoice[invoice] = credit_by_invoice.get(invoice, 0.0) + amount

        # 2. One payment per invoice for the cash part (+ withholding tax as write-off).
        to_pay = []
        for line in self.line_ids.filtered(lambda l: not l.is_refund):
            cash = currency.round(line.amount_settle - credit_by_invoice.get(line, 0.0) - line.wht_amount)
            if currency.compare_amounts(cash, 0.0) < 0:
                raise UserError(_("%s: credit notes and withholding tax exceed the amount settled.",
                                  line.move_id.display_name))
            if currency.is_zero(cash):
                if not currency.is_zero(line.wht_amount):
                    raise UserError(_("%s: a withholding tax needs a cash payment on the same invoice.",
                                      line.move_id.display_name))
                continue
            to_pay.append([line, cash])

        difference = currency.round(self.payment_difference)
        if currency.compare_amounts(difference, 0.0) > 0:
            if not to_pay or currency.compare_amounts(to_pay[-1][1], difference) <= 0:
                raise UserError(_("The difference (%s) is larger than the last payment.", currency.format(difference)))

        payment_model = self.env['account.payment']
        if not self.payment_method_line_id.payment_account_id:
            # Make sure the payment gets a journal entry so it can be reconciled with the invoice.
            payment_model = payment_model.with_context(force_payment_move=True)

        payments = self.env['account.payment']
        for index, (line, cash) in enumerate(to_pay):
            move = line.move_id
            invoice_lines = self._get_term_lines(move)
            writeoffs = []
            amount = cash
            if not currency.is_zero(line.wht_amount):
                writeoffs.append(self._writeoff_vals(self.wht_account_id, _("Withholding tax"), line.wht_amount))
            if index == len(to_pay) - 1 and currency.compare_amounts(difference, 0.0) > 0:
                amount -= difference
                writeoffs.append(self._writeoff_vals(self.writeoff_account_id, self.writeoff_label, difference))
            memo = f"{self.communication or note.name} / {move.name}"
            payment = payment_model.create(self._prepare_payment_vals(
                amount, memo, destination_account=invoice_lines.account_id[:1],
                note_line=line.note_line_id, writeoffs=writeoffs))
            payment = payment.with_env(self.env)
            payment.action_post()
            if not payment.move_id:
                raise UserError(_("Payment %s has no journal entry: set an outstanding account on the payment "
                                  "method of journal %s.", payment.display_name, self.journal_id.display_name))
            self._reconcile_and_track(self._get_term_lines(payment.move_id) + invoice_lines, line.note_line_id)
            move.matched_payment_ids = [Command.link(payment.id)]
            payments |= payment

        # 3. Money received above what was expected stays open on the partner (advance).
        if currency.compare_amounts(difference, 0.0) < 0:
            advance = payment_model.create(self._prepare_payment_vals(
                -difference, f"{self.communication or note.name} / {_('Advance')}"))
            advance.with_env(self.env).action_post()
            payments |= advance

        note.message_post(body=_("Payment registered: %(amount)s received, %(count)s payment(s) created.",
                                 amount=currency.format(self.amount_received), count=len(payments)))
        if not payments:
            return {'type': 'ir.actions.act_window_close'}
        return payments._get_records_action(name=_("Payments"), context={'create': False})


class BillingNoteRegisterPaymentLine(models.TransientModel):
    _name = 'billing.note.register.payment.line'
    _description = "Register Payment from Billing Note - Line"

    wizard_id = fields.Many2one('billing.note.register.payment', required=True, ondelete='cascade')
    currency_id = fields.Many2one(related='wizard_id.currency_id')
    note_line_id = fields.Many2one('billing.note.line', required=True)
    move_id = fields.Many2one(related='note_line_id.move_id')
    invoice_date_due = fields.Date(related='note_line_id.invoice_date_due')
    is_refund = fields.Boolean(compute='_compute_is_refund')
    amount_open = fields.Monetary(string="Amount Due")
    amount_settle = fields.Monetary(string="Amount to Settle")
    wht_amount = fields.Monetary(string="Withholding Tax")
    amount_credit = fields.Monetary(string="Credit Notes Applied", compute='_compute_allocation')
    amount_cash = fields.Monetary(string="Cash", compute='_compute_allocation')

    @api.depends('note_line_id')
    def _compute_is_refund(self):
        for line in self:
            line.is_refund = line.move_id.move_type in ('out_refund', 'in_refund')

    @api.depends('wizard_id.line_ids.amount_settle', 'wizard_id.line_ids.wht_amount')
    def _compute_allocation(self):
        for wizard in self.wizard_id:
            allocations, _unallocated = wizard._allocate_credit_notes()
            credit = {}
            for _refund, invoice, amount in allocations:
                credit[invoice] = credit.get(invoice, 0.0) + amount
            for line in wizard.line_ids & self:
                if line.is_refund:
                    line.amount_credit = 0.0
                    line.amount_cash = 0.0
                else:
                    line.amount_credit = credit.get(line, 0.0)
                    line.amount_cash = line.amount_settle - line.amount_credit - line.wht_amount
        for line in self.filtered(lambda l: not l.wizard_id):
            line.amount_credit = line.amount_cash = 0.0
